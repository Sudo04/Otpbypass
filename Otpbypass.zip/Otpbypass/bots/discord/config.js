module.exports = {
    apiurl: 'http://localhost:1337',
    apipassword: '',

    discordtoken: '',
    discordprefix: '!',
    secretpassword: 'ChAnGeThIsWiThYoUrPaSsWoRdNoW!',
    botuser_rolename: 'Bot User',
    admin_rolename: 'Admin'
};